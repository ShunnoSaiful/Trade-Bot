from django.apps import AppConfig


class TradebotappConfig(AppConfig):
    name = 'tradebotapp'
