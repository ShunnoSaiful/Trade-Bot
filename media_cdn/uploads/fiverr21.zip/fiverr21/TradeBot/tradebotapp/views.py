from django.shortcuts import render
from .models import Answer, Question, Plan, Description, Download





def section_view(request):
	descriptions = Description.objects.all()
	answers = Answer.objects.all()
	plans = Plan.objects.all()
	questions = Question.objects.all()
	download = Download.objects.all()
	context = {
		"answers": answers,
		"questions": questions,
		"plans": plans,
		"descriptions": descriptions,
		"download": download,
	}
	return render(request, "index.html", context)


